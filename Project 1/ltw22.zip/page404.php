<?php 
	include_once('includes/init.php');
	
	include_once('templates/common/page404.php');
?>