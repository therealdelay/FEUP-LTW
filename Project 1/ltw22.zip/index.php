<?php 
	include_once('includes/init.php');
	
	include_once('templates/common/header_landing_page.php');
	include_once('templates/introduction/introduction.php');
	include_once('templates/common/footer.php');
?>