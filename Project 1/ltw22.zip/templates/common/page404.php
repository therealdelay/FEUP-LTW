<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>404</title>
	<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<link href="https://fonts.googleapis.com/css?family=Nunito:400,800" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="css/page404.css">
</head>
<body>
	<h1>404 you should not be here</h1>
	<img src="images/stop.jpeg" alt="stop">
	<a href="index.php">Go back to where you belong<br></a>
</body>
</html>