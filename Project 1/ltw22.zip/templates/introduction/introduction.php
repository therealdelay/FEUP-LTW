<div id="jumbotron">
	<button onclick="location.href='templates/common/register_form.php'">Get Started</button>
</div>